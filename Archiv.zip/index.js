const Alexa = require('ask-sdk');
const fetch = require('node-fetch'); 
const async = require('async');

/**
 * This is a skript for a Amazon Alexa Skill
 * 
 * This skill lets you lock the doors of your mercedes car by saying: "Alexa lock my mercedes!";
 */

/**
 * Handler for the LaunchRequest and the 'LockMyMercedes' Intent
 */
const LockMyMercedesHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest'
      || (request.type === 'IntentRequest'
        && request.intent.name === 'LockMyMercedes');
  },
  async handle(handlerInput) {

    const {accessToken} = handlerInput.requestEnvelope.context.System.user;
    console.log(accessToken);

    if(!accessToken){
      const speechOutput = 'You must first login to your mercedes account';

      return handlerInput.responseBuilder
        .speak(speechOutput)
        .withLinkAccountCard()
        .getResponse();
    } else {

    var access_token = handlerInput.requestEnvelope.context.System.user.accessToken;
    
    var vehicle_id = await getVehicleId();
  
    
    

    console.log(access_token);

    //This variable is used to store if your car is locked
    //false = unlocked
    //true = locked
    var locked = false;

    async function getVehicleId() {

      var res = await fetch('https://api.mercedes-benz.com/experimental/connectedvehicle/v1/vehicles', {
        method: 'get',
        headers:{
          'accept': 'application/json',
          'Authorization': 'Bearer ' + access_token
        }
      });

      var result = await res.json();
      console.log(result);
      return result[0]['id'];
      
    }

    async function lockDoors() {

        console.log('The given grant is valid. Trying to connect to the car');
          
        var locked = await checkDoorStatus();
        if(locked == true){
          return 'Your car has been locked.';
        }else {
          return 'There was an error communicating with your car. Your car has not been locked.';
        }
      }
    
    async function checkDoorStatus() {
      //Get command to get the door status of a vehicle 
      var res = await fetch('https://api.mercedes-benz.com/experimental/connectedvehicle/v1/vehicles/' + vehicle_id + '/doors', {
        method: 'get',
        headers: {
          'accept': 'application/json',
          'Authorization': 'Bearer ' + access_token
        }
      });
        
        //Turn the result into json format
        var result = await res.json();
        console.log(result);
        //If the lock status of the vehicle is locked return true
        if (result.doorlockstatusvehicle.value == 'LOCKED') {
          console.log('All doors locked');
          locked = true;
          console.log('Locked? ' + locked);
          return true;
        } 
        //Else lock the doors
        else {
          return await lockAllDoors();
        }
      }
    
    /**
     * This function sends a post fetch to the vehicle to get lock all doors. 
     * The result of this step is only a INITIATED message.
     * To verify, if the doors are locked the checkDoorStatus() function is called again.
     * If all the doors are locked the checkDoorStatus() function will return true. This result
     * will also be returned by the lockAllDoors().
     */
    async function lockAllDoors() {
      //Post command to lock all doors of a specific vehicle
      var res = await fetch('https://api.mercedes-benz.com/experimental/connectedvehicle/v1/vehicles/' + vehicle_id + '/doors', {
        method: 'post',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + access_token
        },
        body: '{ \"command\": \"LOCK\"}'
      });
        //Parse the result to json format
        var result = await res.json();
        //To verify, that all doors are locked, check the door status
        return await checkDoorStatus();
      }
    
    const speechOutput = await lockDoors();
    
    console.log('response:' + speechOutput);

    //Communication with the mercedes API
    //End

    //Return the speechOutput for Alexa, based on the result of the lock door functions
    return handlerInput.responseBuilder
      .speak(speechOutput)
      .getResponse();
    }
},
};

//=======================================================
// Standard Alexa intents
//=======================================================

const HelpHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(HELP_MESSAGE)
      .reprompt(HELP_REPROMPT)
      .getResponse();
  },
};

const ExitHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && (request.intent.name === 'AMAZON.CancelIntent'
        || request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    return handlerInput.responseBuilder
      .speak(STOP_MESSAGE)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);

    return handlerInput.responseBuilder
      .speak('Sorry, we coudnt connect with your car. Error')
      .reprompt('Sorry, we coudnt connect with your car. Error')
      .getResponse();
  },
};

const SKILL_NAME = 'Lock My Mercedes';
const HELP_MESSAGE = 'Say Lock my car to get your car locked.';
const HELP_REPROMPT = 'What can I help you with?';
const STOP_MESSAGE = 'Goodbye!';

const skillBuilder = Alexa.SkillBuilders.standard();

exports.handler = skillBuilder
  .addRequestHandlers(
    LockMyMercedesHandler,
    HelpHandler,
    ExitHandler,
    SessionEndedRequestHandler
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();
